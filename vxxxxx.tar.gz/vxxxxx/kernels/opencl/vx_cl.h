
#include <VX/vx_khr_opencl.h>

#ifndef _VX_CL_H_
#define _VX_CL_H_

const sampler_t nearest_clamp = CLK_NORMALIZED_COORDS_FALSE | CLK_ADDRESS_CLAMP_TO_EDGE | CLK_FILTER_NEAREST;

#endif

